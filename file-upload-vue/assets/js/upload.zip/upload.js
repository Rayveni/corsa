ELEMENT.locale(ELEMENT.lang.ruRU);

new Vue({
  el: '#app',
  data: {
    backendUrl: 'http://127.0.0.1:5001/upload',
            form: {
            username: '',
            password: ''
        },
    rules: {
      username: [
        {
          required: true,
          message: 'Поле username - обязательное',
          trigger: 'blur',
        },
      ],
      report: [  
        {
          required: true,
          message: 'Поле Отчёт - обязательное',
          trigger: 'blur',
        },
      ],
    },
  },
  methods: {
    handleFileUpload(event) {
      this.file = event.target.files[0];
    },

    onSubmit: function (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {

          let formData = new FormData();
          formData.append('file', this.file);
    
          formData.append(
            'report_params',
            JSON.stringify({
              user: 'jskart23',
              report: 'eeeeee',
              load_mode: 'other',
              auto_extrapolation: false,
            })
          );
          console.log(this.form.username);
          axios({
            method: 'post',
            url: this.backendUrl,
            data: formData,
            headers: { 'Content-Type': 'multipart/form-data' },
          })
            .then((response) => {
              console.log('success');
              console.log(response);
            })
            .catch((response) => {
              console.log('error');
              console.log(response);
            });
     
        } else {
            return false;
        }
    });

     },
  },
  mounted: function () {},
});
